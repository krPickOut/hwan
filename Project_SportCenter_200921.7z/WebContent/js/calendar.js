
//----------------------------------------------------------------
// var dayList = ['일', '월', '화','수','목','금','토'];
// var monthList = ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'];

const init = {
	monList: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
	dayList: ['일', '월', '화', '수', '목', '금', '토'],
//  monList: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
//  dayList: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  today: new Date(),	//	날짜 객체 생성
  monForChange: new Date().getMonth(),	//	새로운 날짜에 월 가져옴 , Month값은 0부터 시작??
  activeDate: new Date(),	//	날짜 객체 생성2
  getFirstDay: (yy, mm) => new Date(yy, mm, 1),	//	처음 일수  , 형식은 아마도 ( yy, mm, dd )
  getLastDay: (yy, mm) => new Date(yy, mm + 1, 0),	//	마지막 일수
  
  nextMonth: function () {	//	다음 월 함수
    let d = new Date();	//	let은 재정의 가능, const는 불가능
    d.setDate(1);	//	새로운 객체에 일수를 1로 지정 (31일 에서 30일인 월로 변환될때 이중으로 넘어갈수있다?)
    d.setMonth(++this.monForChange);	//	this 현재 객체 값을 먼저 더하고 함수실행
    this.activeDate = d;
    return d;
  },
  prevMonth: function () {	//	이전 월 함수
    let d = new Date();
    d.setDate(1);
    d.setMonth(--this.monForChange);
    this.activeDate = d;
    return d;
  },
  
  addZero: (num) => (num < 10) ? '0' + num : num,	//	앞에 0을 추가??
  activeDTag: null,
  
  getIndex: function (node) {	
    let index = 0;
    while (node = node.previousElementSibling) { //	node가 node의 형제요소와 같다면 index 상승?? 흠..
      index++;
    }
    return index;
  }
};

//----------------------------------------------------------------

var start_date = new Date();
var end_date = new Date();
var start;
var end;
var startCount = false;
var endCount = false;

//----------------------------------------------------------------

const $calBody = document.querySelector('.cal-body');	//	$는 j쿼리 변수 = j쿼리 내부함수를 모두사용가능
const $btnNext = document.querySelector('.btn-cal.next');	//	제공한 선택자 또는 선택자 뭉치와 일치하는 문서 내 첫 번째 Element 선택?
const $btnPrev = document.querySelector('.btn-cal.prev');	//	= 해당 클래스의 첫번째 요소를 선택??

/**
 * @param {number} date
 * @param {number} dayIn
*/
//function loadDate (date, dayIn) {	//	innerText 는 불필요한 공백제거(trim 비슷한거 같다), textContent는 문자열 그대로 가져옴
function loadDate (date) {	//	innerText 는 불필요한 공백제거(trim 비슷한거 같다), textContent는 문자열 그대로 가져옴
	
  document.querySelector('.cal-date').textContent = date + "일"; 	//	해당 클래스에 date 추가
  document.querySelector('.cal-day').textContent = (init.activeDate.getMonth()+1) + "월";
//  document.querySelector('.cal-day').textContent = init.dayList[dayIn] ;	//	해당 클래스에  init의 요일 출력
  
  //document.querySelector('.startdate').textContent = start_date;		//	시작일
}

/**
 * @param {date} fullDate
 */
function loadYYMM (fullDate) {
  let yy = fullDate.getFullYear();	//	yy에 fullDate 연도를 가져옴
  let mm = fullDate.getMonth();		//	mm에 fullDate 월 가져옴
  let firstDay = init.getFirstDay(yy, mm);	//	yy, mm 에 해당하는 첫 일수 가져옴
  let lastDay = init.getLastDay(yy, mm);	//	yy, mm 에 해당하는 마지막 일수 가져옴
  let markToday;  // for marking today date = 오늘 날 표시?
  
  if (mm === init.today.getMonth() && yy === init.today.getFullYear()) {
    markToday = init.today.getDate();	//	==(2개) 는 자동 형변환 되어 비교
  }										//	===(3개) 는 형변환 하지않고 비교
  //	mm이 현재 월이고, yy가 현재 연도일때	markToday에 현재 일수를 저장
  
  document.querySelector('.cal-year').textContent = yy+"년";		//	현재	연도를 출력
  document.querySelector('.cal-month').textContent = init.monList[mm];	//	현재 월을 출력
  

  let trtd = '';	//	tr, td, 문자열 총합
  let startCount;
  let countDay = 0;	//	for문 에서 일수 카운트
  for (let i = 0; i < 6; i++) {	// 세로 6 ( 6주? )
    trtd += '<tr>';
    for (let j = 0; j < 7; j++) {	//	가로 7 (요일)
      if (i === 0 && !startCount && j === firstDay.getDay()) {	//	i가 0이고, startCount가 null이고
        startCount = 1;		//	결론은 첫 시작일때 startCount를 부여! ( getDay는 요일을 반환 일요일= 0 부터 시작)
      }
      if (!startCount) {	//	startCount가 값이 있을때 
        trtd += '<td>';
      } else {
        let fullDate = yy + '-' + init.addZero(mm + 1) + '-' + init.addZero(countDay + 1);	//	연도.월수.일수 (addZero : 10이하일대 앞에 0추가) = YYYY.mm.DD
        trtd += '<td class="day';
        trtd += (markToday && markToday === countDay + 1) ? ' today" ' : '"';
        //	markToday가 있고 markToday가 countDay + 1(카운트되고있는 날짜) 같을때 비교	___	true 는 
        //	현재 일수 클래스는 day today 다른 일수 클래스는 day로 지정
        trtd += ` id="${fullDate}" `;
        trtd += ` data-date="${countDay + 1}" data-fdate="${fullDate}">`;	// 흠... date-date 통째로 변수인가?
      }		//	변수일 경우 	date-date는 count+1 저장, data-fdate는 fullDate 를 저장
      trtd += (startCount) ? ++countDay : '';	// startCount가 있다면 ( 날짜표시가 시작됬다면) countDay 상승
      if (countDay === lastDay.getDate()) { 
        startCount = 0; // 마지막 일수일때 시작카운트 0으로 초기화
      }
      trtd += '</td>';
    }
    trtd += '</tr>';
  }
//  console.log(trtd); // 콘솔 출력
  $calBody.innerHTML = trtd;
}

/**
 * @param {string} val
 */
function createNewList (val) {
  let id = new Date().getTime() + '';
  let yy = init.activeDate.getFullYear();	//	activeDate 는 두번째로 만든 날짜 객체 연도 저장
  let mm = init.activeDate.getMonth() + 1;	//	activeDate 는 월 반환
  let dd = init.activeDate.getDate();		//  activeDate 는 일수 반환
//  const $target = $calBody.querySelector(`.day[data-date="${dd}"]`);
  //	``는 템플릿 리터럴, 사용 시 가독성이 좋다
  //(예시)"저는 " + (a + b) + "살이고 " + c + "를 좋아합니다.";
  //	 '저는 ${a+b}살이고 ${c}를 좋아합니다.`;
  //	위 두 문장은 같은 결과를 출력한다		=> date-date는 dd값을 받는다  

  let date = yy + '.' + init.addZero(mm) + '.' + init.addZero(dd);

  let eventData = {};
  eventData['date'] = date;
  eventData['memo'] = val;
  eventData['complete'] = false;
  eventData['id'] = id;
  init.event.push(eventData);	//	이벤트 적용할 날짜 지정??
  $todoList.appendChild(createLi(id, val, date));
  // node :  여러 가지 DOM 타입들이 상속하는 인터페이스
  // appendChild() : 노드를 현재 위치에서 새로운 위치로 이동시킵니다..?
}

loadYYMM(init.today);	//	현재 기준 테이블 출력
loadDate(init.today.getDate());
//loadDate(init.today.getDate(), init.today.getDay());	//	선택 날짜와 요일 출력

$btnNext.addEventListener('click', () => loadYYMM(init.nextMonth()));	//	addEventListener = 이벤트 핸들러 등록??
$btnPrev.addEventListener('click', () => loadYYMM(init.prevMonth()));	//	클릭시 이전 이후 월 불러오기

$calBody.addEventListener('click', (e) => {	//	calbody : tbody(일수) 내용
// &(이벤트대상).지정?(기타 매개변수)
	
  if (e.target.classList.contains('day')) {
    if (init.activeDTag) {
      init.activeDTag.classList.remove('day-active');
    }//	day-active 클래스 삭제 if 문을 먼저 호출
    
    let day = Number(e.target.textContent);	//	e(클릭한타겟) 의 일수 저장
//   loadDate(day, e.target.cellIndex);
    loadDate(day);
    e.target.classList.add('day-active');
    init.activeDTag = e.target;
    init.activeDate.setDate(day);	//	activeDate 객체에 클릭한 날짜 저장
//  reloadTodo();	//	새로고침 하는거같은데 흠...
 
  
//----------------------------------------------------------------
   

//  if(!start&&end&&init.activeDate.getDate()==end_date.getDate()){  
//	  end = null;
//	  e.target.style.backgroundColor = 'white'; 
//	  document.querySelector('.enddate').textContent = end;
//	  
//	  document.getElementById("inputstart").value = "";
//	  document.proListform.submit();	//	submit
//	  
//  }else if(!start&&init.activeDate.getDate()!=end_date.getDate()){		//	처음 날짜 설정 클릭
////	  init.activeDate;
//	  start_date.setFullYear(init.activeDate.getFullYear());
//	  start_date.setMonth(init.activeDate.getMonth()+1);
//	  start_date.setDate(init.activeDate.getDate());
//	  
//	  start = start_date.getFullYear() + '-' + init.addZero(start_date.getMonth()) + '-' + init.addZero(start_date.getDate()) ;
//	  e.target.style.backgroundColor = 'yellow'; 
//	  document.getElementById("inputstart").value = start;
//	  document.querySelector('.startdate').textContent = start;
//	  document.proListform.submit();	//	submit
//  }else if(start&&!end&&init.activeDate.getDate()!=start_date.getDate()){	//	시작버튼이 눌려있고 종료버튼은 실행 안되있을때 시작일이랑 겹치지 않으면
////	  init.activeDate;
//	  end_date.setFullYear(init.activeDate.getFullYear());	//	end_date 연도	설정
//	  end_date.setMonth(init.activeDate.getMonth()+1);		//	end_date 월 설정
//	  end_date.setDate(init.activeDate.getDate());			//	end_date 일 설정
//	  
//	  end = end_date.getFullYear() + '-' + init.addZero(end_date.getMonth()) + '-' + init.addZero(end_date.getDate()) ;	//	end 에 날짜를 문자열로 저장
//	  e.target.style.backgroundColor = 'green'; 	//	해당 타겟 이벤트 배경색변경
//	  document.getElementById("inputend").value = end;	//	input 값 넣기
//	  document.querySelector('.enddate').textContent = end;		//	선택 일자 표시	
//	  document.proListform.submit();	//	submit
////  }else if(start&&init.activeDate.getDate()==start_date.getDate()){
//  }else if(start&&init.activeDate.getDate()==start_date.getDate()){
//	  start = null;
//	  e.target.style.backgroundColor = 'white'; 
//	  document.querySelector('.startdate').textContent = start;
//	  
//	  document.getElementById("inputstart").value = "";
//	  document.proListform.submit();	//	submit
//	  
//  }else if(end&&init.activeDate.getDate()==end_date.getDate()){
//	  end = null;
//	  e.target.style.backgroundColor = 'white'; 
//	  document.querySelector('.enddate').textContent = end;
//	  
//	  document.getElementById("inputstart").value = "";
//	  document.proListform.submit();	//	submit
//  }
  
//----------------------------------------------------------------
//init.activeDate
//시작
if(!start && !end){  
	starton(init.activeDate,  e.target);
}else if(start && !end && init.activeDate.getDate()!=start_date.getDate()){		
	endon(init.activeDate,  e.target);
}else if(init.activeDate.getDate()==start_date.getDate()){
	startoff(e.target);
}
else if(init.activeDate.getDate()==end_date.getDate()){
	endoff(e.target);
}

//----------------------------------------------------------------
  	
  }
});
function starton(date, select){
	  start_date.setFullYear(date.getFullYear());
	  start_date.setMonth(date.getMonth()+1);
	  start_date.setDate(date.getDate());
	  
	  start = start_date.getFullYear() + '-' + init.addZero(start_date.getMonth()) + '-' + init.addZero(start_date.getDate()) ;
	  select.style.backgroundColor = 'yellow'; 
	  document.getElementById("inputstart").value = start;
	  document.querySelector('.startdate').textContent = start;
	  document.proListform.submit();	//	submit
//	  alert("startOn");
}
function endon(date, select){
	  end_date.setFullYear(date.getFullYear());	//	end_date 연도	설정
	  end_date.setMonth(date.getMonth()+1);		//	end_date 월 설정
	  end_date.setDate(date.getDate());			//	end_date 일 설정
	  
	  end = end_date.getFullYear() + '-' + init.addZero(end_date.getMonth()) + '-' + init.addZero(end_date.getDate()) ;	//	end 에 날짜를 문자열로 저장
	  select.style.backgroundColor = 'green'; 	//	해당 타겟 이벤트 배경색변경
	  document.getElementById("inputend").value = end;	//	input 값 넣기
	  document.querySelector('.enddate').textContent = end;		//	선택 일자 표시	
	  document.proListform.submit();	//	submit
//	  alert("endOn");
}
function startoff(select){
	  start = null;
	  select.style.backgroundColor = 'white'; 
//	  document.querySelector('.startdate').textContent = start;
	  
	  document.getElementById("inputstart").value = start;
	  document.proListform.submit();	//	submit
//	  alert("startOff");
}
function endoff(select){
	  end = null;
	  end_date = null;
	  end_date = new Date();
	  select.style.backgroundColor = 'white'; 
//	  document.querySelector('.enddate').textContent = end;
	  
	  document.getElementById("inputend").value = end;
	  document.proListform.submit();	//	submit
//	  alert("endOff");
}
//----------------------------------------------------------------















