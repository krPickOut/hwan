package program.srv;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.ProgramDAO;
import vo.ProgramList;

public class ProgramListViewService {

	public ArrayList<ProgramList> getProListView() throws Exception {
		ArrayList<ProgramList> proListView = null;
		Connection con = getConnection();
		ProgramDAO programDAO = ProgramDAO.getInstance();
		programDAO.setConnection(con);
		proListView = programDAO.getProList();
		
		close(con);
		return proListView;
	}
	
}
