package program.srv;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.util.ArrayList;
import dao.ProgramDAO;
import vo.ProgramInfo;

public class ProgramInfoViewService{

	public ArrayList<ProgramInfo> getProInfoView() throws Exception{
		ArrayList<ProgramInfo> proInfoView = null;
		Connection con = getConnection();
		ProgramDAO programDAO = ProgramDAO.getInstance();
		programDAO.setConnection(con);
		proInfoView = programDAO.getProInfo();
		
		close(con);
		return proInfoView;
	}

	

}
