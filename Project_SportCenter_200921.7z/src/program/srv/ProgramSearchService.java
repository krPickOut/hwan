package program.srv;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.util.ArrayList;
import dao.ProgramDAO;
import vo.ProgramList;

public class ProgramSearchService {
	
	public ArrayList<ProgramList> getProList(ProgramList searchList) throws Exception{
	ArrayList<ProgramList> proList = null;
	Connection con = getConnection();
	ProgramDAO programDAO = ProgramDAO.getInstance();
	programDAO.setConnection(con);
	proList = programDAO.searchProList(searchList);
	
	close(con);
	return proList;
	}

}
