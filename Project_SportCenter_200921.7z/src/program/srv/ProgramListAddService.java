package program.srv;

import static db.JdbcUtil.*;
import java.sql.Connection;
import dao.ProgramDAO;
import vo.ProgramList;

public class ProgramListAddService {

	public boolean addProList(ProgramList proList) throws Exception{
		Connection con = getConnection();
		ProgramDAO programDAO = ProgramDAO.getInstance();
		programDAO.setConnection(con);
		int proListSet = 0;
		proListSet = programDAO.setProList(proList);
		boolean listSuccess = false;
		
		
		if(proListSet > 0) {
			commit(con);
			listSuccess = true;
		}else {
			rollback(con);
		}
		close(con);
		return listSuccess;
	}
}
