package program.srv;

import static db.JdbcUtil.*;
import java.sql.Connection;
import dao.ProgramDAO;
import vo.ProgramInfo;
import vo.ProgramList;

public class ProgramInfoAddService {
	public boolean addProInfo(ProgramInfo proInfo) throws Exception{
		
		Connection con = getConnection();
		ProgramDAO programDAO = ProgramDAO.getInstance();
		programDAO.setConnection(con);
		int proInfoSet = 0;
		proInfoSet = programDAO.setProInfo(proInfo);
		boolean infoSuccess = false;
		
		
		if(proInfoSet > 0) {
			commit(con);
			infoSuccess = true;
		}else {
			rollback(con);
		}
		close(con);
		return infoSuccess;
	}

}
