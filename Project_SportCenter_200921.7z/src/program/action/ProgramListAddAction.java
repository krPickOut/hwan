package program.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import program.srv.ProgramListAddService;
import vo.ActionForward;
import vo.ProgramList;

public class ProgramListAddAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub

		ProgramList proList = new ProgramList();
		
		proList.setPro_code(Integer.parseInt(request.getParameter("pro_code")));
		System.out.println("proCodeAction : " + request.getParameter("pro_code"));
		
		java.sql.Date start_date = java.sql.Date.valueOf(request.getParameter("start_date"));
		java.sql.Date end_date = java.sql.Date.valueOf(request.getParameter("end_date"));
		java.sql.Date apply_date = java.sql.Date.valueOf(request.getParameter("apply_date"));
		
		proList.setStart_date(start_date);
		proList.setEnd_date(end_date);
		proList.setApply_date(apply_date);
		
		proList.setPro_target(request.getParameter("pro_target"));
		proList.setPro_time(request.getParameter("pro_time"));
		proList.setPro_place(request.getParameter("pro_place"));
		proList.setPro_title(request.getParameter("pro_title"));
		proList.setPro_content(request.getParameter("pro_content"));
		proList.setPro_memo(request.getParameter("pro_memo"));
		proList.setPrice(Integer.parseInt(request.getParameter("price")));
		proList.setMax_people(Integer.parseInt(request.getParameter("max_people")));
		
		ProgramListAddService proAddService = new ProgramListAddService();
		boolean proListSuccess = false;
		proListSuccess = proAddService.addProList(proList);
		ActionForward forward = new ActionForward();
		
		if(!proListSuccess) {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			
			out.println("<script>");
			out.println("alert('강의등록 실패')");
			out.println("history.back()");
			out.println("</script>");
			
		}else {
			forward.setRedirect(false);
			forward.setPath("programListView.do");
		}
		return forward;
	}
}
