package program.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import program.srv.*;
import vo.ActionForward;
import vo.ProgramList;

public class ProgramSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ArrayList<ProgramList> proList = new ArrayList<ProgramList>();
		ProgramList searchList = new ProgramList();
		
		java.sql.Date start_date = null;
		if(!request.getParameter("start_date").equals("")){
			start_date = java.sql.Date.valueOf(request.getParameter("start_date"));
			searchList.setStart_date(start_date);
		}
		java.sql.Date end_date = null;
		if(!request.getParameter("end_date").equals("")) {
			end_date = java.sql.Date.valueOf(request.getParameter("end_date"));
			searchList.setEnd_date(end_date);

		}

		ProgramSearchService proSearchService = new ProgramSearchService();
		proList = proSearchService.getProList(searchList);

		request.setAttribute("proList",proList);	//	조회목록 저장
		ActionForward forward = new ActionForward();
		
		request.setAttribute("pagefile", "/program/program_list_form.jsp?start_date=" + start_date + "&end_date=" + end_date);
		forward.setPath("template.jsp");
		
		return forward;
	}

}
