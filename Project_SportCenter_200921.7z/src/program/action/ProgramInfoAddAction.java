package program.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import program.srv.ProgramInfoAddService;
import vo.ActionForward;
import vo.ProgramInfo;

public class ProgramInfoAddAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ProgramInfo proInfo = new ProgramInfo();
		proInfo.setPro_name(request.getParameter("pro_name"));
		
		ProgramInfoAddService proAddService = new ProgramInfoAddService();
		boolean proInfoSuccess = false;
		proInfoSuccess = proAddService.addProInfo(proInfo);
		ActionForward forward = new ActionForward();
		
		
		
		if(!proInfoSuccess) {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			
			out.println("<script>");
			out.println("alert('과목등록 실패')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			forward.setRedirect(false);
			forward.setPath("programInfoView.do");
		}
		return forward;
	}

}
