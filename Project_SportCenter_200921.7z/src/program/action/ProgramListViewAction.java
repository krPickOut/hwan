package program.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import program.srv.ProgramListViewService;
import vo.ActionForward;
import vo.ProgramList;

public class ProgramListViewAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ArrayList<ProgramList> proListView = new ArrayList<ProgramList>();
		ProgramListViewService proListViewService = new ProgramListViewService();
		proListView = proListViewService.getProListView();

		request.setAttribute("proListView",proListView);	//	조회목록 저장
		
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		request.setAttribute("pagefile", "/program/program_admin_page.jsp");
		request.setAttribute("proAdmin", "/program/program_addList_form.jsp");
		forward.setPath("template.jsp");
		
		return forward;
	}

}
