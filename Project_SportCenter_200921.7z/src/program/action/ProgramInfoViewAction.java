package program.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import program.srv.ProgramInfoViewService;
import vo.ActionForward;
import vo.ProgramInfo;

public class ProgramInfoViewAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ArrayList<ProgramInfo> proInfoView = new ArrayList<ProgramInfo>();
		ProgramInfoViewService proInfoViewService = new ProgramInfoViewService();
		proInfoView = proInfoViewService.getProInfoView();

		request.setAttribute("proInfoView",proInfoView);	//	조회목록 저장
		
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		request.setAttribute("pagefile", "/program/program_admin_page.jsp");
		request.setAttribute("proAdmin", "/program/program_addInfo_form.jsp");
		forward.setPath("template.jsp");
		
		return forward;
	}

}
