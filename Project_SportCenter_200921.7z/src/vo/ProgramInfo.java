package vo;

public class ProgramInfo {
	
	//pro_code 기본키는 자동증가
	private int pro_code;
	private String pro_name;
	
	
	public String getPro_name() {
		return pro_name;
	}
	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}
	public int getPro_code() {
		return pro_code;
	}
	public void setPro_code(int pro_code) {
		this.pro_code = pro_code;
	}

	
	
}
