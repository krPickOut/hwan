package vo;

import java.sql.Date;

public class ProgramList {
	private int list_code;
	private int pro_code;
	private Date start_date;
	private Date end_date;
	private String pro_target;
	private String pro_time;
	private String pro_place;
	private String pro_title;
	private String pro_content;
	private String pro_memo;
	private int price;
	private Date apply_date;
	private int now_people;
	private int max_people;
	
	public int getList_code() {
		return list_code;
	}
	public void setList_code(int list_code) {
		this.list_code = list_code;
	}
	public int getPro_code() {
		return pro_code;
	}
	public void setPro_code(int pro_code) {
		this.pro_code = pro_code;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public String getPro_target() {
		return pro_target;
	}
	public void setPro_target(String pro_target) {
		this.pro_target = pro_target;
	}
	public String getPro_time() {
		return pro_time;
	}
	public void setPro_time(String pro_time) {
		this.pro_time = pro_time;
	}
	public String getPro_place() {
		return pro_place;
	}
	public void setPro_place(String pro_place) {
		this.pro_place = pro_place;
	}
	public String getPro_title() {
		return pro_title;
	}
	public void setPro_title(String pro_title) {
		this.pro_title = pro_title;
	}
	public String getPro_content() {
		return pro_content;
	}
	public void setPro_content(String pro_content) {
		this.pro_content = pro_content;
	}
	public String getPro_memo() {
		return pro_memo;
	}
	public void setPro_memo(String pro_memo) {
		this.pro_memo = pro_memo;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Date getApply_date() {
		return apply_date;
	}
	public void setApply_date(Date apply_date) {
		this.apply_date = apply_date;
	}
	public int getNow_people() {
		return now_people;
	}
	public void setNow_people(int now_people) {
		this.now_people = now_people;
	}
	public int getMax_people() {
		return max_people;
	}
	public void setMax_people(int max_people) {
		this.max_people = max_people;
	}
	
	

}
