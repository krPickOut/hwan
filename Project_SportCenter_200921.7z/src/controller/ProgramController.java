package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import board.action.BoardListAction;
import program.action.*;
import vo.ActionForward;



@WebServlet("*.do")
public class ProgramController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);

	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		String RequestURI = request.getRequestURI();	//	프로젝트와 파일의 경로 요청 : /프로젝트명/파일명.jsp
		String contextPath = request.getContextPath();	//	프로젝트 경로 요청 : /프로젝트명
		String command = RequestURI.substring(contextPath.length());	//	파일명 추출
		
		Action action = null;
		ActionForward forward = null;
		System.out.println(command);

		if(command.equals("/programList.do")) {		//	수강신청 캘린더 리스트
			try {
				forward=new ActionForward();
				forward.setRedirect(false);
				request.setAttribute("pagefile", "/program/program_list_form.jsp");
				forward.setPath("template.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if (command.equals("/programSearch.do")) {	//	수강신청 기간 조회
			action = new ProgramSearchAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if (command.equals("/programAdmin.do")) {		//	관리자 페이지
			try {
				forward=new ActionForward();
				forward.setRedirect(false);
				request.setAttribute("pagefile", "/program/program_admin_page.jsp");
				forward.setPath("template.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if (command.equals("/programInfoView.do")) {		//	과목 리스트 조회
			action = new ProgramInfoViewAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if (command.equals("/programInfoAdd.do")) {		//	과목 추가
			action = new ProgramInfoAddAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if (command.equals("/programListAdd.do")) {		// 강의 리스트 조회
			action = new ProgramListAddAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if (command.equals("/programListView.do")) {		//	강의 추가
			action = new ProgramListViewAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

			
			
			
		if (forward != null) {
			if (forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
				// forward 주소 redirect
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);

			}
		}

	}

}
