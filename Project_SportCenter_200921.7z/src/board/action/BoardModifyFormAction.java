package board.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import sun.misc.Perf.GetPerfAction;
import board.svc.BoardDetailService;
import vo.ActionForward;
import vo.BoardBean;

public class BoardModifyFormAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ActionForward forward = new ActionForward();
		int board_num = Integer.parseInt(request.getParameter("board_num"));
		BoardDetailService boardDetailService = new BoardDetailService();
		BoardBean article = boardDetailService.getAriticle(board_num);
		request.setAttribute("article", article);
		forward.setRedirect(false);
		
		if(request.getParameter("freepage")!=null) {
			request.setAttribute("pagefile", "/freeboard/free_board_modify.jsp");
		}
		if(request.getParameter("proudpage")!=null) {
			request.setAttribute("pagefile", "/proudboard/proud_board_modify.jsp");
		}
		if(request.getParameter("qnapage")!=null) {
			request.setAttribute("pagefile", "/qnaboard/qna_board_modify.jsp");
		}
		forward.setPath("template.jsp");
		
		return forward;
	}

}

