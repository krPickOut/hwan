package board.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import board.svc.BoardDetailService;
import vo.ActionForward;
import vo.BoardBean;

public class BoardReplyFormAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ActionForward forward = new ActionForward();
		String nowPage = "";
		String boardtype = "";
		if(request.getParameter("freepage")!=null) {
			nowPage = request.getParameter("freepage");
			boardtype = "1";
		}
		else if(request.getParameter("proudpage")!=null) {
			nowPage = request.getParameter("proudpage");
			boardtype = "2";
		}
		else if(request.getParameter("qnapage")!=null) {
			nowPage = request.getParameter("qnapage");
			boardtype = "3";
		}
		
		int board_num = Integer.parseInt(request.getParameter("board_num"));
		BoardDetailService boardDetailService = new BoardDetailService();
		BoardBean article = boardDetailService.getAriticle(board_num);
		request.setAttribute("article", article);
		request.setAttribute("page", nowPage);
		forward.setRedirect(false);
		
		if(request.getParameter("freepage")!=null) {
			request.setAttribute("pagefile", "/freeboard/free_board_reply.jsp");
			forward.setPath("template.jsp");
		}
		else if(request.getParameter("proudpage")!=null) {
			request.setAttribute("pagefile", "/proudboard/proud_board_reply.jsp");
			forward.setPath("template.jsp");
		}
		else if(request.getParameter("qnapage")!=null) {
			request.setAttribute("pagefile", "/qnaboard/qna_board_reply.jsp");
			forward.setPath("template.jsp");
		}	
		
		return forward;
	}

}
