package board.action;

import java.util.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import board.svc.BoardListService;
import vo.ActionForward;
import vo.BoardBean;
import vo.PageInfo;

public class BoardListAction implements Action {
	
	private String boardtype;
	
	public BoardListAction(String boardtype) {
		// TODO Auto-generated constructor stub
		this.boardtype = boardtype;
	}

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ArrayList<BoardBean> articleList = new ArrayList<BoardBean>();
		int page = 1;
		int limit = 10;
		int limitPage=5;
		if(boardtype.equals("1")) {
			if(request.getParameter("freepage")!= null) {
				page = Integer.parseInt(request.getParameter("freepage"));
			}
		}else if(boardtype.equals("2")) {
			if(request.getParameter("proudpage")!= null) {
				page = Integer.parseInt(request.getParameter("proudpage"));
			}
		}else if(boardtype.equals("3")) {
			if(request.getParameter("qnapage")!= null) {
				page = Integer.parseInt(request.getParameter("qnapage"));
			}
		}
			
		BoardListService boardListService = new BoardListService();
		int listCount = boardListService.getListCount(boardtype);
		articleList = boardListService.getArticleList(page,limit,boardtype);
		
		int maxPage=(int)((double)listCount/limit+0.95);

		
//		int startPage = (((int) ((double)page / 10 + 0.9)) - 1) * 10 + 1;
//		int endPage = startPage+10-1;
		
		int startPage = (((int) ((double)page / limitPage + 0.9)) - 1) * limitPage + 1;		
		int endPage = startPage+limitPage-1;
		
		if(endPage>maxPage) endPage = maxPage;
		
		PageInfo pageInfo = new PageInfo();
		pageInfo.setEndPage(endPage);
		pageInfo.setListCount(listCount);
		pageInfo.setMaxPage(maxPage);
		pageInfo.setPage(page);
		pageInfo.setStartPage(startPage);
		if(boardtype.equals("1")) {
			request.setAttribute("freePageInfo", pageInfo);
		}else if(boardtype.equals("2")) {
			request.setAttribute("proudPageInfo", pageInfo);
		}else if(boardtype.equals("3")) {
			request.setAttribute("qnaPageInfo", pageInfo);
		}
		request.setAttribute("articleList",articleList);
		ActionForward forward = new ActionForward();
		if(boardtype.equals("1")) {
			request.setAttribute("pagefile", "/freeboard/free_board_list.jsp");
			forward.setPath("template.jsp");
		}else if(boardtype.equals("2")) {
			request.setAttribute("pagefile", "/proudboard/proud_board_list.jsp");
			forward.setPath("template.jsp");
		}else if(boardtype.equals("3")) {
			request.setAttribute("pagefile", "/qnaboard/qna_board_list.jsp");
			forward.setPath("template.jsp");
		}
		
		return forward;
	}

}
