package board.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import board.svc.BoardDetailService;
import vo.ActionForward;
import vo.BoardBean;

public class BoardDetailAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		int board_num = Integer.parseInt(request.getParameter("board_num"));
		String page="";
		String boardtype="";
		if(request.getParameter("freepage")!=null) {
			page = request.getParameter("freepage");
			boardtype="1";
		}
		else if(request.getParameter("proudpage")!=null) {
			page = request.getParameter("proudpage");
			boardtype="2";
		}
		else if(request.getParameter("qnapage")!=null) {
			page = request.getParameter("qnapage");
			boardtype="3";
		}
		
		BoardDetailService boardDetailService = new BoardDetailService();
		BoardBean article = boardDetailService.getAriticle(board_num);
		ActionForward forward = new ActionForward();
		request.setAttribute("page", page);
		request.setAttribute("article", article);
		forward.setRedirect(false);
		
		if(boardtype.equals("1")) {
			request.setAttribute("pagefile", "/freeboard/free_board_view.jsp");
			forward.setPath("template.jsp");
		}
		else if(boardtype.equals("2")) {
			request.setAttribute("pagefile", "/proudboard/proud_board_view.jsp");
			forward.setPath("template.jsp");
		}
		else if(boardtype.equals("3")) {
			request.setAttribute("pagefile", "/qnaboard/qna_board_view.jsp");
			forward.setPath("template.jsp");
		}	
		return forward;
	}

}
