package board.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import board.svc.BoardModifyProService;
import vo.ActionForward;
import vo.BoardBean;
import vo.PageInfo;

public class BoardModifyProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
			ActionForward forward = null;
			boolean isModifySuccee = false;
			int board_num = Integer.parseInt(request.getParameter("board_num"));
			BoardBean article = new BoardBean();
			BoardModifyProService boardModifyProservice = new BoardModifyProService();
			boolean isRightUser=boardModifyProservice.isArticleWriter(board_num, request.getParameter("board_pass"));
			
			String boardtype = request.getParameter("board_category");
			
		if(!isRightUser) {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('수정할 권한이 없습니다.');");
			out.println("history.back();");
			out.println("</script>");
		}else {
			article.setBoard_num(board_num);
			article.setBoard_title(request.getParameter("board_title"));
			article.setBoard_content(request.getParameter("board_content"));
			isModifySuccee = boardModifyProservice.modifyArticle(article);
			
			if(!isModifySuccee) {
				response.setContentType("text/html;charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.println("<script>");
				out.println("alert('수정실패');");
				out.println("history.back();");
				out.println("</script>");
			}else {
				forward = new ActionForward();
				forward.setRedirect(false);
//				forward.setPath("boardDetail.bo?board_num="+article.getBoard_num());
	
				if(boardtype.equals("1")) {	
					forward.setPath("boardDetail.bo?board_num="+article.getBoard_num()+"&freepage=1");
				}
				if(boardtype.equals("2")) {
					forward.setPath("boardDetail.bo?board_num="+article.getBoard_num()+"&proudpage=1");
				}
				if(boardtype.equals("3")) {
					forward.setPath("boardDetail.bo?board_num="+article.getBoard_num()+"&qnapage=1");
				}
			}
		}
		
		return forward;
	}

}
