package board.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import board.svc.BoardReplyProService;
import vo.ActionForward;
import vo.BoardBean;

public class BoardReplyProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		String nowPage="";
		if(request.getParameter("freepage")!=null);{
			 nowPage = request.getParameter("freepage");
			 
		}
		if(request.getParameter("proudpage")!=null);{
			 nowPage = request.getParameter("proudpage");
		}
		if(request.getParameter("qnapage")!=null);{
			 nowPage = request.getParameter("qnapage");
		}
		System.out.println("nowPage : " + nowPage);
			
		BoardBean article = new BoardBean();
		article.setBoard_num(Integer.parseInt(request.getParameter("board_num")));
		article.setBoard_id(request.getParameter("board_id"));
		article.setBoard_pass(request.getParameter("board_pass"));
		article.setBoard_title(request.getParameter("board_title"));
		article.setBoard_content(request.getParameter("board_content"));
		article.setBoard_re_ref(Integer.parseInt(request.getParameter("board_re_ref")));
		article.setBoard_re_lev(Integer.parseInt(request.getParameter("board_re_lev")));
		article.setBoard_re_seq(Integer.parseInt(request.getParameter("board_re_seq")));
		article.setBoard_category(request.getParameter("board_category"));
		BoardReplyProService boardReplyProService = new BoardReplyProService();
		boolean isReplySuccess = boardReplyProService.replyArticle(article);
		
		String boardtype = request.getParameter("board_category");
		if(isReplySuccess) {
			forward = new ActionForward();
			forward.setRedirect(false);
			if(boardtype.equals("1")) {
				forward.setPath("boardList.bo?freepage="+nowPage+"&boardtype='1'");
			}
			else if(boardtype.equals("2")) {
				forward.setPath("boardList.bo?proudpage="+nowPage+"&boardtype='2'");
			}
			else if(boardtype.equals("3")) {
				forward.setPath("boardList.bo?qnapage="+nowPage+"&boardtype='3'");
			}
			
		}else {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('답장실패');");
			out.println("history.back();");
			out.println("<script>");
				
		}
		
		return forward;
	}

}
