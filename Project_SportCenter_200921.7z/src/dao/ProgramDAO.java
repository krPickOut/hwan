package dao;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.sql.DataSource;

import vo.ProgramInfo;
import vo.ProgramList;

public class ProgramDAO {

	DataSource ds;
	Connection con;
	private static ProgramDAO programDAO;
	
	private ProgramDAO() {}
	
	public static ProgramDAO getInstance() {
		// TODO Auto-generated method stub
		if(programDAO == null) {
			programDAO = new ProgramDAO();
		}
		return programDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}
	
	//프로그램 설정 후 조회 ---------------------------------------------------------------
	public ArrayList<ProgramList> searchProList(ProgramList searchList) {
		// TODO Auto-generated method stub
		
		ArrayList<ProgramList> proList = new ArrayList<ProgramList>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Date start = searchList.getStart_date();
		Date end = searchList.getEnd_date();
		
		System.out.println("start : " + start);
		System.out.println("end : " + end);
		
		try {
			String search_sql= "select * from program_list ";
//			search_sql+="and start_date > replace(?,'-','') and end_date <= replace(?,'-','')";
			if(start!=null&&end==null) {
				search_sql += " where start_date > replace(?,'-','')";
			}else if(start==null&&end!=null) {
				search_sql += " where end_date <= replace(?,'-','')";
			}else if(start!=null&&end!=null) {
				search_sql += " where start_date > replace(?,'-','') and end_date <= replace(?,'-','')";
			}
			pstmt=con.prepareStatement(search_sql);
			
			if(start!=null&&end==null) {
				pstmt.setDate(1, start);
			}else if(start==null&&end!=null) {
				pstmt.setDate(1, end);
			}else if(start!=null&&end!=null) {
				pstmt.setDate(1, start);
				pstmt.setDate(2, end);
			}
			
			//-------------
			rs = pstmt.executeQuery();
			if(rs!=null) {
				while(rs.next()) {
					ProgramList proInfo = new ProgramList();
					proInfo.setList_code(rs.getInt("list_code"));
					proInfo.setPro_code(rs.getInt("pro_code"));
					proInfo.setStart_date(rs.getDate("start_date"));
					proInfo.setEnd_date(rs.getDate("end_date"));
					proInfo.setPrice(rs.getInt("price"));
					proList.add(proInfo);
				}
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("프로그램 조회 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return proList;
	}
	//	주문신청 프로그램 조회-------------------------------------------------------------------

	public ProgramList searchProList(int listCode) {
		
		ProgramList proInfo = new ProgramList();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String search_sql ="";
			
			search_sql= "select * from program_list where list_code= ?";

			pstmt=con.prepareStatement(search_sql);
			pstmt.setInt(1, listCode);
			rs = pstmt.executeQuery();
			
			if(rs!=null) {
				while(rs.next()) {
					proInfo.setList_code(rs.getInt("list_code"));
					proInfo.setPro_code(rs.getInt("pro_code"));
					proInfo.setStart_date(rs.getDate("start_date"));
					proInfo.setEnd_date(rs.getDate("end_date"));
					proInfo.setPrice(rs.getInt("price"));
				}
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("수강신청 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return proInfo;
	}
	
	//	 프로그램 과목 등록-------------------------------------------------------------------
	
	public int setProInfo(ProgramInfo proInfo) {
		// TODO Auto-generated method stub
		PreparedStatement pstmt = null;
		int proInfoCount = 0;
		
		try {
			String proInfo_sql ="insert into program_info ";
			proInfo_sql += " ( pro_name ) ";
			proInfo_sql += " values ( ? )";
			
			pstmt=con.prepareStatement(proInfo_sql);
			pstmt.setString(1, proInfo.getPro_name());
		
			proInfoCount = pstmt.executeUpdate();

		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("과목등록 에러 : " + ex);
		}finally {
			
			close(pstmt);
		}
		return proInfoCount;
	}

	//	-------------------------------------------------------------------
	
	public int setProList(ProgramList proList) {
		// TODO Auto-generated method stub
		 
		PreparedStatement pstmt = null;
		int proListCount = 0;
		
		System.out.println("1 : " + proList.getPro_code());
		System.out.println("2 : " + proList.getStart_date());
		System.out.println("3 : " + proList.getEnd_date());
		System.out.println("4 : " + proList.getPro_target());
		System.out.println("5 : " + proList.getPro_time());
		System.out.println("6 : " + proList.getPro_place());
		System.out.println("7 : " + proList.getPro_title());
		System.out.println("8 : " + proList.getPro_content());
		System.out.println("9 : " + proList.getPro_memo());
		System.out.println("10 : " + proList.getPrice());
		System.out.println("11 : " + proList.getApply_date());
		System.out.println("12 : " + proList.getNow_people());
		System.out.println("13 : " + proList.getMax_people());

		System.out.println();
		
		
		
		
		try {
			String proList_sql ="insert into program_list ";
			proList_sql += " ( pro_code, start_date, end_date, ";
			proList_sql += " pro_target, pro_time, pro_place, pro_title, pro_content, pro_memo, ";
			proList_sql +=	" price, apply_date, max_people	) ";
			proList_sql += " values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
			
			System.out.println(proList_sql);
			
			pstmt=con.prepareStatement(proList_sql);
			
			pstmt.setInt(1, proList.getPro_code());
			pstmt.setDate(2, proList.getStart_date());
			pstmt.setDate(3, proList.getEnd_date());
			pstmt.setString(4, proList.getPro_target() != null?proList.getPro_target():"");
			pstmt.setString(5, proList.getPro_time()  != null?proList.getPro_time():"");
			pstmt.setString(6, proList.getPro_place()  != null?proList.getPro_place():"");
			pstmt.setString(7, proList.getPro_title());
			pstmt.setString(8, proList.getPro_content()  != null?proList.getPro_content():"");
			pstmt.setString(9, proList.getPro_memo()  != null?proList.getPro_memo():"");
			pstmt.setInt(10, proList.getPrice());
			pstmt.setDate(11, proList.getApply_date());
			pstmt.setInt(12, proList.getMax_people());
			
			proListCount = pstmt.executeUpdate();
			
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("강의등록 에러 : " + ex);
		}finally {
			
			close(pstmt);
		}
		return proListCount;
	}

	//	-------------------------------------------------------------------
	
	public ArrayList<ProgramInfo> getProInfo() {
		ArrayList<ProgramInfo> proInfoView = new ArrayList<ProgramInfo>();
		ProgramInfo proInfo = new ProgramInfo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String proInfoView_sql ="select * from program_info";

			pstmt=con.prepareStatement(proInfoView_sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				proInfo.setPro_code(Integer.parseInt(rs.getString("pro_code")));
				proInfo.setPro_name(rs.getString("pro_name"));
//				proInfo.setMax_people(Integer.parseInt(rs.getString("max_people")));
				proInfoView.add(proInfo);
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("과목조회 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return proInfoView;
	}

//	-------------------------------------------------------------------
	
	public ArrayList<ProgramList> getProList() {
		ArrayList<ProgramList> proListView = new ArrayList<ProgramList>();
		ProgramList proList = new ProgramList();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String proListView_sql ="select * from program_list";

			pstmt=con.prepareStatement(proListView_sql);
			rs = pstmt.executeQuery();
			
			if(rs!=null) {
				while(rs.next()) {
					proList.setList_code(rs.getInt("list_code"));
					proList.setPro_code(rs.getInt("pro_code"));
					proList.setStart_date(rs.getDate("start_date"));
					proList.setEnd_date(rs.getDate("end_date"));
					proList.setPro_target(rs.getString("pro_target"));
					proList.setPro_time(rs.getString("pro_time"));
					proList.setPro_place(rs.getString("pro_place"));
					proList.setPro_title(rs.getString("pro_title"));
					proList.setPro_content(rs.getString("pro_content"));
					proList.setPro_memo(rs.getString("pro_memo"));
					proList.setApply_date(rs.getDate("apply_date"));
					proList.setNow_people(Integer.parseInt(rs.getString("now_people")));
					proList.setMax_people(Integer.parseInt(rs.getString("max_people")));
					proListView.add(proList);
				}
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("강의조회 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return proListView;
	}

	
	
	
}
