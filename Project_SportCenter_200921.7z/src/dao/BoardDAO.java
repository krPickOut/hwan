package dao;

import static db.JdbcUtil.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.sql.DataSource;
import vo.BoardBean;



public class BoardDAO {

	DataSource ds;
	Connection con;
	private static BoardDAO boardDAO;
	
	private BoardDAO() {
		
	}
	
	public static BoardDAO getInstance() {
		// TODO Auto-generated method stub
		if(boardDAO == null) {
			boardDAO = new BoardDAO();
		}
		return boardDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}

	public int selectListCount(String board_category) {
		// 페이지
		int listCount = 0;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt=con.prepareStatement("select count(*) from board where board_category=?");
			pstmt.setString(1, board_category);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				listCount=rs.getInt(1);
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("getListCount 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return listCount;
	}
	
	public ArrayList<BoardBean> selectArticleList(int page, int limit, String boardtype) {
		// TODO Auto-generated method stub
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_list_sql="select * from board where board_category=" + boardtype ;
			board_list_sql+=" order by board_re_ref desc,board_re_seq asc limit ?,10";
		ArrayList<BoardBean> articleList = new ArrayList<BoardBean>();
		BoardBean board = null;
		int startrow = (page-1)*10;
		
		
		try {
			pstmt=con.prepareStatement(board_list_sql);
			pstmt.setInt(1, startrow);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				board = new BoardBean();
				board.setBoard_num(rs.getInt("board_num"));
				board.setBoard_id(rs.getString("board_id"));
				board.setBoard_title(rs.getString("board_title"));
				board.setBoard_content(rs.getString("board_content"));
				board.setBoard_file(rs.getString("board_file"));
				board.setBoard_re_ref(rs.getInt("board_re_ref"));
				board.setBoard_re_lev(rs.getInt("board_re_lev"));
				board.setBoard_re_seq(rs.getInt("board_re_seq"));
				board.setBoard_readcount(rs.getInt("board_readcount"));
				board.setBoard_date(rs.getDate("board_date"));
				articleList.add(board);
				
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("getBoardList 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return articleList;
	}
	
	public BoardBean selectArticle(int board_num) {
		// TODO Auto-generated method stub
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BoardBean boardBean = null;

		try {
			pstmt=con.prepareStatement(
			"select * from board where board_num = ?");
			pstmt.setInt(1, board_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				boardBean = new BoardBean();
				boardBean.setBoard_num(rs.getInt("board_num"));
				boardBean.setBoard_id(rs.getString("board_id"));
				boardBean.setBoard_title(rs.getString("board_title"));
				boardBean.setBoard_content(rs.getString("board_content"));
				boardBean.setBoard_file(rs.getString("board_file"));
				boardBean.setBoard_re_ref(rs.getInt("board_re_ref"));
				boardBean.setBoard_re_lev(rs.getInt("board_re_lev"));
				boardBean.setBoard_re_seq(rs.getInt("board_re_seq"));
				boardBean.setBoard_readcount(rs.getInt("board_readcount"));
				boardBean.setBoard_date(rs.getDate("board_date"));
		
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("getDetail 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return boardBean;
	}
	
	public int insertArticle(BoardBean article) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int num = 0;
		String sql="";
		int insertCount=0;

		try {
			pstmt=con.prepareStatement(
			"select max(board_num) from board");
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				num = rs.getInt(1)+1;
			}else {
				num=1;
			}
			sql="insert into board (board_num, board_id, board_pass, board_title,";
			sql+="board_content, board_file, board_re_ref, ";
			sql+="board_re_lev, board_re_seq, board_readcount,";
			sql+="board_date, board_category ) values (?,?,?,?,?,?,?,?,?,?,now(),?)";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, article.getBoard_id());
			pstmt.setString(3, article.getBoard_pass());
			pstmt.setString(4, article.getBoard_title());
			pstmt.setString(5, article.getBoard_content());
			pstmt.setString(6, article.getBoard_file());
			pstmt.setInt(7,num);
			pstmt.setInt(8,0);
			pstmt.setInt(9,0);
			pstmt.setInt(10,0);
			pstmt.setString(11, article.getBoard_category());
			
			insertCount=pstmt.executeUpdate();
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("boardInsert 에러 : " + ex);
		}finally {
			close(rs);
			close(pstmt);
		}
		return insertCount;
	}

	public int insertReplyArticle(BoardBean article) {
		// TODO Auto-generated method stub
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_max_sql ="select max(board_num) from board"; 
		String sql="";
		int num = 0;
		int insertCount=0;
		int re_ref=article.getBoard_re_ref();
		int re_lev=article.getBoard_re_lev();
		int re_seq=article.getBoard_re_seq();

		try {
			pstmt=con.prepareStatement(board_max_sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				num = rs.getInt(1)+1;
			}else {
				num=1;
			}
			sql="update board set board_re_seq=board_re_seq+1 where board_re_ref = ? ";
			sql+="and board_re_seq>?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, re_ref);
			pstmt.setInt(2, re_seq);
			int updateCount = pstmt.executeUpdate();
			if(updateCount > 0) {
				commit(con);
			}
			re_seq = re_seq + 1;
			re_lev = re_lev + 1;
			
			sql="insert into board (board_num, board_id, board_pass, board_title,";
			sql+="board_content, board_file, board_re_ref, board_re_lev, board_re_seq,";
			sql+="board_readcount, board_date, board_category) ";
			sql+=" values( ?,?,?,?,?,?,?,?,?,?,now(), ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, article.getBoard_id());
			pstmt.setString(3, article.getBoard_pass());
			pstmt.setString(4, article.getBoard_title());
			pstmt.setString(5, article.getBoard_content());
			pstmt.setString(6, "");
			pstmt.setInt(7,re_ref);
			pstmt.setInt(8,re_lev);
			pstmt.setInt(9,re_seq);
			pstmt.setInt(10,0);
			pstmt.setString(11, article.getBoard_category());
			insertCount = pstmt.executeUpdate();
			
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("boardReply 에러 : " + ex);
		}finally {
			
			close(rs);
			close(pstmt);
		}
		return insertCount;
	}

	public int updateArticle(BoardBean article) {
		int updateCount=0;
		PreparedStatement pstmt = null;
		String sql = "update board set board_title = ?, board_content=? where board_num=?";
		
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, article.getBoard_title());
			pstmt.setString(2, article.getBoard_content());
			pstmt.setInt(3, article.getBoard_num());
			updateCount = pstmt.executeUpdate();
			
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("boardModify 에러 : " + ex);
		}finally {
			
			close(pstmt);
		}
		return updateCount;
		
	}
	
	public int deleteArticle(int board_num) {
		PreparedStatement pstmt = null;
		String board_delete_sql ="delete from board where board_num=?";
		int deleteCount = 0;
		
		try {
			pstmt=con.prepareStatement(board_delete_sql);
			pstmt.setInt(1, board_num);
			deleteCount=pstmt.executeUpdate();
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("boardDelete 에러 : " + ex);
		}finally {
			close(pstmt);
		}
		
		return deleteCount;
	}
	
	public int updateReadCount(int board_num) {
		PreparedStatement pstmt = null;
		int updateCount = 0;
		String sql ="update board set board_readcount = " + "board_readcount+1 where board_num = " + board_num;
		
		try {
			pstmt=con.prepareStatement(sql);
			updateCount=pstmt.executeUpdate();
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("boardDelete 에러 : " + ex);
		}finally {
			close(pstmt);
		}
		
		return updateCount;
	}



	public boolean isArticleBoardWriter(int board_num, String pass) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String board_sql="select *from board where board_num=?";
		boolean isWriter = false;
		
		try {
			pstmt=con.prepareStatement(board_sql);
			pstmt.setInt(1, board_num);
			rs=pstmt.executeQuery();
			rs.next();
			
			if(pass.equals(rs.getString("board_pass"))) {
				isWriter = true;
			}
		}catch (Exception ex) {
			// TODO: handle exception
			System.out.println("isBoardWriter 에러 : " + ex);
		}finally {
			close(pstmt);
		}
		
		return isWriter;
	}




	





}
